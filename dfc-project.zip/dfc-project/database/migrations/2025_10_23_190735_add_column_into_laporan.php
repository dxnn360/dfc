<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('laporan_penyelidikan', function (Blueprint $table) {
            $table->string('pekerjaan')->nullable();
            $table->string('organisasi')->nullable();
            $table->string('sumber_permintaan')->nullable();
            $table->string('no_telp')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('laporan_penyelidikan', function (Blueprint $table) {
            $table->dropColumn(['pekerjaan', 'organisasi', 'sumber_permintaan', 'no_telp']);
        });
    }
};
