<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-6 py-6">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">Daftar Laporan Penyelidikan</h1>
            <a href="<?php echo e(route('analis.laporan.create')); ?>" 
               class="px-4 py-2 bg-blue-600 text-white rounded">+ Buat Laporan</a>
        </div>

        <div class="bg-white shadow rounded p-4">
            <table class="w-full border-collapse border">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="border px-3 py-2">No</th>
                        <th class="border px-3 py-2">Nomor Surat</th>
                        <th class="border px-3 py-2">Nama Pemohon</th>
                        <th class="border px-3 py-2">Tanggal</th>
                        <th class="border px-3 py-2">Status</th>
                        <th class="border px-3 py-2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = is_iterable($laporan) ? $laporan : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="border px-3 py-2"><?php echo e($loop->iteration); ?></td>
                            <td class="border px-3 py-2"><?php echo e(is_object($item) && isset($item->nomor_surat) ? $item->nomor_surat : '-'); ?></td>
                            <td class="border px-3 py-2"><?php echo e(is_object($item) && isset($item->nama_pemohon) ? $item->nama_pemohon : '-'); ?></td>
                            <td class="border px-3 py-2">
                                <?php echo e(is_object($item) && isset($item->tanggal) ? \Carbon\Carbon::parse($item->tanggal)->format('d M Y') : '-'); ?>

                            </td>
                            <td class="border px-3 py-2">
                                <span class="px-2 py-1 text-sm rounded 
                                    <?php echo e((is_object($item) && isset($item->status) && $item->status === 'draft') ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'); ?>">
                                    <?php echo e(is_object($item) && isset($item->status) ? ucfirst($item->status) : '-'); ?>

                                </span>
                            </td>
                            <td class="border px-3 py-2 space-x-2">
                                <?php if(is_object($item) && isset($item->id)): ?>
                                    <a href="<?php echo e(route('analis.laporan.edit', $item->id)); ?>" class="text-blue-600">Edit</a>
                                    <a href="<?php echo e(route('analis.laporan.download', $item->id)); ?>" class="text-green-600">Download</a>
                                    <form action="<?php echo e(route('analis.laporan.destroy', $item->id)); ?>" 
                                          method="POST" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" onclick="return confirm('Yakin hapus?')" 
                                                class="text-red-600">Hapus</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-gray-400">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="border px-3 py-2 text-center text-gray-500">Belum ada laporan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Project\dfc\dfc-project\resources\views/analis/laporan_penyelidikan/index.blade.php ENDPATH**/ ?>