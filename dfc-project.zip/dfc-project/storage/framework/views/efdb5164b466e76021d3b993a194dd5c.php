<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <!-- Header Section -->
        <div class="mb-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Dashboard Supervisor</h1>
                    <p class="mt-2 text-gray-600">Overview dokumen dan aktivitas terbaru</p>
                </div>
                <div class="mt-4 sm:mt-0">
                    <div class="text-sm text-gray-500 bg-white px-4 py-2 rounded-lg shadow-sm border">
                        Hi, <?php echo e(auth()->user()->name); ?>👋
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <!-- Surat Tugas Card -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Surat Tugas</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e($suratTugas->count()); ?></p>
                        <p class="text-xs text-gray-500 mt-1">Dokumen aktif</p>
                    </div>
                    <div class="p-3 bg-blue-50 rounded-lg">
                        <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Surat Pengantar Card -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Surat Pengantar</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e($suratPengantar->count()); ?></p>
                        <p class="text-xs text-gray-500 mt-1">Dokumen aktif</p>
                    </div>
                    <div class="p-3 bg-green-50 rounded-lg">
                        <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Laporan Pemeriksaan Card -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total Laporan Pemeriksaan</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e($laporan->count()); ?></p>
                        <p class="text-xs text-gray-500 mt-1">Dokumen aktif</p>
                    </div>
                    <div class="p-3 bg-purple-50 rounded-lg">
                        <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Documents Section -->
        <div class="space-y-8">
            <!-- Surat Tugas Terbaru -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="bg-gradient-to-r from-blue-50 to-blue-100 px-6 py-4 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            5 Surat Tugas Terbaru
                        </h2>
                        <a href="<?php echo e(route('supervisor.document')); ?>"
                            class="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
                            Lihat Semua
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </a>
                    </div>
                </div>
                <div>
                    <?php if (isset($component)) { $__componentOriginal4c16aca2f2a1b8f012393620cb8771cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c16aca2f2a1b8f012393620cb8771cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.surat-tugas-table-spv','data' => ['suratTugas' => $suratTugas->take(5),'showPagination' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('surat-tugas-table-spv'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['suratTugas' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($suratTugas->take(5)),'showPagination' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c16aca2f2a1b8f012393620cb8771cb)): ?>
<?php $attributes = $__attributesOriginal4c16aca2f2a1b8f012393620cb8771cb; ?>
<?php unset($__attributesOriginal4c16aca2f2a1b8f012393620cb8771cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c16aca2f2a1b8f012393620cb8771cb)): ?>
<?php $component = $__componentOriginal4c16aca2f2a1b8f012393620cb8771cb; ?>
<?php unset($__componentOriginal4c16aca2f2a1b8f012393620cb8771cb); ?>
<?php endif; ?>
                </div>
            </div>

            <!-- Surat Pengantar Terbaru -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="bg-gradient-to-r from-green-50 to-green-100 px-6 py-4 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                            <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            5 Surat Pengantar Terbaru
                        </h2>
                        <a href="<?php echo e(route('supervisor.document')); ?>"
                            class="text-sm text-green-600 hover:text-green-700 font-medium flex items-center gap-1">
                            Lihat Semua
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </a>
                    </div>
                </div>
                <div>
                    <?php if (isset($component)) { $__componentOriginal6c7487fe45a372544a658dcfa823dbb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6c7487fe45a372544a658dcfa823dbb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.surat-pengantar-table-spv','data' => ['suratPengantar' => $suratPengantar->take(5),'showPagination' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('surat-pengantar-table-spv'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['suratPengantar' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($suratPengantar->take(5)),'showPagination' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6c7487fe45a372544a658dcfa823dbb9)): ?>
<?php $attributes = $__attributesOriginal6c7487fe45a372544a658dcfa823dbb9; ?>
<?php unset($__attributesOriginal6c7487fe45a372544a658dcfa823dbb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c7487fe45a372544a658dcfa823dbb9)): ?>
<?php $component = $__componentOriginal6c7487fe45a372544a658dcfa823dbb9; ?>
<?php unset($__componentOriginal6c7487fe45a372544a658dcfa823dbb9); ?>
<?php endif; ?>
                </div>
            </div>

            <!-- Laporan Pemeriksaan Terbaru -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="bg-gradient-to-r from-purple-50 to-purple-100 px-6 py-4 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                            <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            5 Laporan Pemeriksaan Terbaru
                        </h2>
                        <a href="<?php echo e(route('supervisor.document')); ?>"
                            class="text-sm text-purple-600 hover:text-purple-700 font-medium flex items-center gap-1">
                            Lihat Semua
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </a>
                    </div>
                </div>
                <div>
                    <?php if (isset($component)) { $__componentOriginal5c1ceab942598c785f992758e4c676aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c1ceab942598c785f992758e4c676aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-pemeriksaan-table-spv','data' => ['laporan' => $laporan->take(5),'showPagination' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-pemeriksaan-table-spv'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['laporan' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->take(5)),'showPagination' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c1ceab942598c785f992758e4c676aa)): ?>
<?php $attributes = $__attributesOriginal5c1ceab942598c785f992758e4c676aa; ?>
<?php unset($__attributesOriginal5c1ceab942598c785f992758e4c676aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c1ceab942598c785f992758e4c676aa)): ?>
<?php $component = $__componentOriginal5c1ceab942598c785f992758e4c676aa; ?>
<?php unset($__componentOriginal5c1ceab942598c785f992758e4c676aa); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Project\dfc\dfc-project\resources\views/supervisor/dashboard.blade.php ENDPATH**/ ?>