<?php
    $menus = [];

    if(auth()->check()) {
        if(auth()->user()->hasRole('admin')) {
            $menus = [
                ['label' => 'Dashboard', 'url' => route('admin.dashboard'), 'icon' => asset('images/icons/dashboard.png')],
                ['label' => 'Pengguna', 'url' => route('users.index'), 'icon' => asset('images/icons/user.png')],
                ['label' => 'Pengaturan', 'url' => route('profile.edit'), 'icon' => asset('images/icons/setting.png')],
            ];
        } elseif(auth()->user()->hasRole('analis')) {
            $menus = [
                ['label' => 'Dashboard', 'url' => route('analis.dashboard'), 'icon' => asset('images/icons/dashboard.png')],
                ['label' => 'Dokumen', 'url' => route('analis.document'), 'icon' => asset('images/icons/document.png')],
                ['label' => 'Pengaturan', 'url' => route('profile.edit'), 'icon' => asset('images/icons/setting.png')],
            ];
        } elseif(auth()->user()->hasRole('supervisor')) {
            $menus = [
                ['label' => 'Dashboard', 'url' => route('supervisor.dashboard'), 'icon' => asset('images/icons/dashboard.png')],
                ['label' => 'Dokumen', 'url' => route('supervisor.document'), 'icon' => asset('images/icons/document.png')],
                ['label' => 'Pengaturan', 'url' => '#', 'icon' => asset('images/icons/setting.png')],
            ];
        }
    }
?>

<div class="flex">
    <?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => ['menus' => $menus]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['menus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menus)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
    <main class="flex-1 p-6">
        <?php echo e($slot); ?>

    </main>
</div>
<?php /**PATH D:\Project\dfc\dfc-project\resources\views/components/sidebar-layout.blade.php ENDPATH**/ ?>