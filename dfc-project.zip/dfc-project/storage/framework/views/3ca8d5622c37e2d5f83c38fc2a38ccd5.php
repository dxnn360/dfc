<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Daftar Surat Tugas')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="flex justify-between items-center mb-6">
                <a href="<?php echo e(route('analis.surat_tugas.create')); ?>" 
                   class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 text-sm">
                    + Buat Surat Tugas
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="mb-4 p-3 bg-green-100 text-green-800 rounded text-sm">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white shadow-sm rounded-lg overflow-hidden">
                <table class="w-full border-collapse">
                    <thead>
                        <tr class="bg-gray-100 text-left text-xs uppercase tracking-wider">
                            <th class="p-3 border">No</th>
                            <th class="p-3 border">Nomor Surat</th>
                            <th class="p-3 border">Tanggal</th>
                            <th class="p-3 border">Nama Pemohon</th>
                            <th class="p-3 border">Status</th>
                            <th class="p-3 border">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $suratTugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-sm hover:bg-gray-50">
                                <td class="p-3 border text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="p-3 border"><?php echo e($surat_tugas->nomor_surat); ?></td>
                                <td class="p-3 border"><?php echo e(\Carbon\Carbon::parse($surat_tugas->tanggal)->format('d-m-Y')); ?></td>
                                <td class="p-3 border"><?php echo e($surat_tugas->nama_pemohon); ?></td>
                                <td class="p-3 border">
                                    <?php if($surat_tugas->status === 'pending'): ?>
                                        <span class="px-3 py-1 rounded-full bg-yellow-500 text-white text-xs">Pending</span>
                                    <?php elseif($surat_tugas->status === 'disetujui'): ?>
                                        <span class="px-3 py-1 rounded-full bg-green-500 text-white text-xs">Disetujui</span>
                                    <?php else: ?>
                                        <span class="px-3 py-1 rounded-full bg-red-500 text-white text-xs">Ditolak</span>
                                    <?php endif; ?>
                                </td>
                                <td class="p-3 border flex gap-2">
                                    <a href="<?php echo e(route('analis.surat_tugas.download', $surat_tugas->id)); ?>"
                                       class="px-3 py-1 bg-blue-500 text-white rounded text-xs hover:bg-blue-600">
                                        Download
                                    </a>
                                    <a href="<?php echo e(route('analis.surat_tugas.edit', $surat_tugas->id)); ?>"
                                       class="px-3 py-1 bg-yellow-500 text-white rounded text-xs hover:bg-yellow-600">
                                        Edit
                                    </a>
                                    <form action="<?php echo e(route('analis.surat_tugas.destroy', $surat_tugas->id)); ?>" method="POST" onsubmit="return confirm('Yakin hapus data ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                            class="px-3 py-1 bg-red-500 text-white rounded text-xs hover:bg-red-600">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="p-3 border text-center text-gray-500">Belum ada surat tugas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Project\dfc\dfc-project\resources\views/analis/surat_tugas/index.blade.php ENDPATH**/ ?>